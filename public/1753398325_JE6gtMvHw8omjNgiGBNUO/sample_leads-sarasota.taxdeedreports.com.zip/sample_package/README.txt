-------------------------------------------------------------------------------
🐊  Tax Deed & Surplus Funds Leads Sample — Sarasota County, FL  ☀️
-------------------------------------------------------------------------------

**Generated:** `2025-07-28`

This archive contains structured data on **Sarasota County, Florida** tax deed surplus cases.

Use it to identify surplus recovery opportunities, analyze auction trends, or discover potential leads for outreach.

---

## 📁 Included Files

- `sarasota_leads_2025-07-28.csv`  
  → One row per tax deed case with metadata, status, and sale/surplus info.

- `sarasota_leads_2025-07-28_parties.csv`  
  → One row per party associated with a case (owners, applicants, lienholders, etc.)

- `sarasota_leads_2025-07-28_documents.csv`  
  → One row per document linked to a case, with category, filename, and upload metadata.

- `sarasota_leads_2025-07-28_value_history.csv`  
  → Year-by-year property valuation and tax data.

- `sarasota_leads_2025-07-28_sales_history.csv`  
  → Past sales data including sale price, seller, deed type, and links to documents.

- `documents/`  
  → PDF files referenced in the `documents.csv`.

---

## ✅ cases.csv - Fields Overview

| Field                | Description                                                       |
|----------------------|-------------------------------------------------------------------|
| `caseId`             | Unique internal case ID (used as a foreign key)                  |
| `case_number`        | Official tax deed case number                                    |
| `address`            | Property address (from county appraiser)                         |
| `status`             | Case status (e.g. ACTIVE, REDEMPTION, SOLD)                      |
| `surplus_balance`    | Surplus amount (if any) reported by the county                   |
| `date`               | Tax deed application date                                        |
| `sale_date`          | Scheduled or completed auction date                              |
| `app_receive_date`   | Date application was received by the Clerk of Court              |
| `parcel_num`         | County parcel ID number                                          |
| `application_num`    | Tax deed application reference number                            |
| `municipality`       | Jurisdiction or city                                             |
| `subdivision`        | Recorded subdivision name                                        |
| `property_use`       | County's land use classification                                 |
| `homestead`          | Whether the property is flagged as a homestead (true/false)      |
| `zoning`             | Zoning code (e.g. RSF-2, CG)                                     |
| `land_area`          | Lot size (square feet)                                           |
| `living_units`       | Number of residential units                                      |
| `ownership_info`     | Owner(s) as listed by the property appraiser                     |
| `prop_appr_url`      | Link to official property appraiser record                       |
| `latest_sale_price`  | Last sale price on record                                        |
| `latest_sale_date`   | Last recorded sale date                                          |
| `latest_sale_seller` | Seller from last transaction                                     |
| `flood_zone`         | FEMA flood zone classification                                   |
| `flood_sfha`         | Is the property in a Special Flood Hazard Area? (true/false)     |
| `floodway`           | Is the property in a FEMA floodway? (true/false)                 |
| `auction_scheduled`  | Is the auction scheduled? (true/false)                           |
| `surplus_available`  | Is surplus available for this case? (true/false)                 |
| `doc_count`          | Total number of linked documents                                 |
| `legal_description`  | Full legal description of the property                           |
| `winning_bid`        | Final bid amount (if sold at auction)                            |
| `r4c-opening-bid`    | Clerk's opening bid amount at auction                            |

---

## 🧾 Supporting CSVs

### parties.csv

| Field            | Description                                                            |
|------------------|------------------------------------------------------------------------|
| `caseId`         | References `caseId` in `cases.csv`                                     |
| `name`           | Name of the person or entity                                           |
| `type`           | Role (OWNER, APPLICANT, LIENHOLDER, etc.)                              |
| `street_address` | Mailing address                                                        |
| `city`           | City                                                                   |
| `state`          | State                                                                  |
| `postal`         | Postal code                                                            |
| `country`        | Country                                                                |

### documents.csv

| Field            | Description                                                            |
|------------------|------------------------------------------------------------------------|
| `caseId`         | References `caseId` in `cases.csv`                                     |
| `document_id`    | Internal document ID                                                   |
| `doctype`        | Document type (e.g. CASE_LOG, NOTICE)                                  |
| `category`       | Document category                                                      |
| `orig_filename`  | Original uploaded filename                                             |
| `upload_date`    | Date the file was posted                                               |
| `local_filename` | Filename used in the archive                                           |

### value_history.csv

| Field         | Description                                                    |
|---------------|----------------------------------------------------------------|
| `caseId`      | References `caseId` in `cases.csv`                             |
| `year`        | Year of the valuation                                          |
| `land`        | Land value                                                     |
| `just`        | Just value (land + buildings)                                  |
| `mrkt_ases`   | Market-assessed value                                          |
| `capped_ases` | SOH-capped assessed value                                      |
| `taxable`     | Final taxable value                                            |
| `exempt`      | Total exemptions                                               |

### sales_history.csv

| Field          | Description                                                    |
|----------------|----------------------------------------------------------------|
| `caseId`       | References `caseId` in `cases.csv`                             |
| `sale_price`   | Sale price                                                     |
| `date`         | Sale date                                                      |
| `file_number`  | File or instrument number                                      |
| `seller`       | Seller name                                                    |
| `type`         | Sale type (e.g. Warranty Deed, Quit Claim, Trustee)           |
| `document_url` | Direct URL to the document                                     |

---

## 🛠️ Usage

You can import the CSVs into **Excel**, **Google Sheets**, **Airtable**, or a **database** for filtering, querying, and outreach.

---

## 🙋 Questions? Requests?

We're here for it.

Need a **custom format?** Want to target a **different county?**  
Looking to **build a tool** with this data?

> It doesn't hurt to ask — you might be surprised! 😄

---

### 👨‍💻 Created by Rick & Olivia  
**Software Engineers & Proprietors**  
🌐 [TaxDeedReports.com](https://taxdeedreports.com)  
📧 contact@taxdeedreports.com

_A project by New Literacy Technology Consultants — [NewLiteracy.online](https://newliteracy.online)_

