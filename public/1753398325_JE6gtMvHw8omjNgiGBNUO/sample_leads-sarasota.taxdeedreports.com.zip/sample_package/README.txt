-------------------------------------------------------------------------------
    🐊 Tax Deed and Surplus Funds Leads Sample for Sarasota County, FL  ☀️
-------------------------------------------------------------------------------

Generated: 2025-07-24

This archive contains structured data on Sarasota County tax deed surplus cases.
Use it to identify potential surplus recovery opportunities or analyze auction
trends.
-----------------------------
    Included Files:
-----------------------------
- sarasota_leads_2025-07-24.csv
→ One row per tax deed case with metadata, status, and sale/surplus information.

- sarasota_leads_2025-07-24_parties.csv
→ One row per party associated with a case (owners, applicants, lienholders, etc.)

- sarasota_leads_2025-07-24_documents.csv
→ One row per document linked to a case, with category, filename, and upload metadata.

- documents/
→ PDF files referenced in the documents CSV.

-----------------------------
    ✅ Fields Overview:
-----------------------------

cases CSV:
- caseId 
- case_number
- application_num
- parcel_num
- status
- sale_date
- surplus_balance
- owner_names
- auction_scheduled
- surplus_available
- legal_description
- doc_count
- document_links

-----------------------------
    🧾 Supporting CSVs:
-----------------------------
    parties CSV:
    - caseId (references 🔗 caseId in cases CSV)
    - name
    - type
    - street_address
    - city
    - state
    - postal
    - country

    documents CSV:
    - caseId (references 🔗 caseId in cases CSV)
    - document_id
    - doctype
    - category
    - orig_filename
    - upload_date
    - local_filename



-----------------------------
    🛠️ Usage: 👩🏻‍💻
-----------------------------

You can import these CSV files into Excel, Google Sheets, or any database for 
analysis.

THANK YOU FOR YOUR INTEREST IN OUR PRODUCT.

FEEL FREE TO REACH OUT WITH ANY QUESTIONS AT ALL.

WE HOPE TO PROVIDE YOU WITH **EXACTLY** THE DATA THAT YOU NEED. 

YOUR FEEDBACK HELPS US IMPROVE OUR PRODUCT. ❤️

IF IT'S NOT POSSIBLE, IT'S NOT POSSIBLE... 🤷 

IT DOESN'T HURT TO ASK BECAUSE YOU MIGHT BE SUPRISED!!! :)



Sincerely, 



Rick and Olivia

Software Engineers and Proprietors 

🌐 TaxDeedReports.com
📧 contact@taxdeedreports.com

---
New Literacy Technology Consultants
🌐 NewLiteracy.online

